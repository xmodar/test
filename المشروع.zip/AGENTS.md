# AGENTS.md

Instructions for any AI coding agent working on this project.

## About the project owner

- The owner is **non-technical** and prefers **Arabic**.
- Assume no programming knowledge. Never assume they know what a terminal, file path, package, API, or "commit" is unless you explain it.

## Language rules

- **Think, plan, and work in English**: code, comments, file names, commit messages, documentation, and internal reasoning are all in English.
- **Every reply to the owner must be in Arabic** (Modern Standard Arabic, simple and clear).
- Keep unavoidable technical terms in English inside the Arabic text, followed by a short Arabic explanation the first time they appear. Example: «Git (أداة تحفظ نسخًا من المشروع يمكن الرجوع إليها)».

## How to communicate

### After every change
End each task with a short Arabic summary that answers, without jargon:
1. **ماذا تغيّر؟** What changed, described by what the user will see or experience, not by file or function names.
2. **لماذا؟** Why it was needed.
3. **هل يحتاج منك شيئًا؟** Whether the owner needs to do anything. If not, say so explicitly.
4. **كيف تتأكد؟** How to check it works (only if the owner can check it themselves).

Keep it brief. Use bullet points. Do not paste code unless asked.

### When there is a decision to make
- Present the options in plain Arabic, ideally 2–4 options.
- For each option, state: what it means in practice, its pros, its cons, and a rough cost/effort/time if relevant.
- Clearly mark your **recommendation** and explain why in one or two sentences.
- Use everyday analogies when they help.
- Do not ask the owner to decide on purely technical details that have a standard best practice; decide those yourself and mention the choice briefly.

### When the owner must do something outside the app
Anything the owner has to do themselves (create an account, get an API key, pay for a service, change a setting on a website, install a program, upload a file, etc.) must be given as **numbered, step-by-step instructions in Arabic**:
- One action per step.
- Name the exact buttons, menus, and links as they appear on screen (keep the original English label if the interface is in English, e.g. «اضغط على زر **Settings**»).
- Say what the owner should expect to see after the step.
- Say exactly what to copy and send back to you, if anything.
- Warn clearly about anything sensitive (passwords, keys, payments) and never ask the owner to paste secrets into a place where they would be saved in the project or shared publicly.
- If a command must be run, give it in its own code block and explain in Arabic what it does and where to paste it.

## Version history (saving every change)

The owner must always be able to return to any earlier version.

- Use **Git** for version control. If the project is not yet a Git repository, initialize one before making changes.
- **Commit after every meaningful change** (each completed task or fix), so each change is a separate restorable version.
- Write commit messages in English, short and descriptive (e.g. `Add PDF upload to CV review page`).
- Never rewrite or delete history (no force-push, no `reset --hard` on shared work, no deleting branches) without the owner's explicit approval.
- Before any risky or large change, make sure the current state is committed first.
- When reporting to the owner, mention in Arabic that the change was saved as a new version, and if they ask how to go back, do it for them or explain in simple steps.
- Keep secrets out of Git: use a `.env` file (or equivalent) that is listed in `.gitignore`, and provide a `.env.example` with placeholder values.

## Engineering best practices

- **Source of truth:** `BRD & Technical Specifications.pdf` in the project root describes the requirements. Read the relevant parts before building features, and point out (in Arabic) any conflict or gap you find instead of guessing silently.
- Prefer simple, well-known, well-maintained tools and libraries over clever or obscure ones.
- Keep code readable: clear names, small focused functions, consistent formatting, comments only where the reason is not obvious.
- Validate all user input and uploaded files (type, size); handle errors gracefully with user-friendly messages.
- Protect personal data: CVs contain personal information. Do not log their contents, store them longer than needed, or send them to third-party services without the owner's informed approval.
- Never hard-code passwords, API keys, or tokens in the code.
- Add or update automated tests for important logic, and run them before declaring a task done. If tests fail, say so honestly.
- Keep a `README.md` up to date with how to run the project (in English), and be ready to explain it to the owner in Arabic.
- Do only what was asked; if you notice other useful improvements, suggest them in Arabic instead of doing them silently.
- Confirm with the owner before anything hard to undo or that affects the outside world: deleting data, deploying/publishing, spending money, or changing external accounts.
- Report outcomes truthfully: if something was not done, not tested, or did not work, say so plainly.
